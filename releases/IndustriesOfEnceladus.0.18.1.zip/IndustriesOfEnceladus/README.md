# [SPDX] Industries of Enceladus

## Features
 * MPUs:
  * Rusatom-Antonoff MPU Mk2: larger than most others with an increased efficiency compared to the basegame version
  * Titan Heavy Industries Bulker MPU: squeezes a massive amount of mineral hold space beneath the unit... at the expense of the processing volume, which is comically difficult to load
	
 * Cargo Bay Accessories:
  * Not usable with the Kitsune, KTA24, Runasimi K37, and OCP
	* Rasamama RP-25: low-profile ore preprocessor that reduces ice content and recovers a modest amount of remass from chunks in the bay
	* Conlido Internal Storage Rack: low-profile storage module that increases mineral hold space
	* 

## Installation (Steam)

1. Open your game install directory
2. Create a new folder called "mods"
3. Place the .zip you downloaded into it (don't extract it!)
4. Right-click on your game install in Steam, select Properties...
5. Put --enable-mods in the LAUNCH OPTIONS box at the bottom of the popup, in the General tab
6. Run dV!