# [SPDX] Industries of Enceladus

## Installation (Steam)

1. Open your game install directory
2. Create a new folder called "mods"
3. Place the .zip you downloaded into it (don't extract it!)
4. Right-click on your game install in Steam, select Properties...
5. Put --enable-mods in the LAUNCH OPTIONS box at the bottom of the popup, in the General tab
6. Run dV!